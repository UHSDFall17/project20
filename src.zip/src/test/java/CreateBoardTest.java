import org.junit.Test;

import static org.junit.Assert.*;

public class CreateBoardTest {
   /* @Test
    public void boardDetails() throws Exception {


    }



    @Test
    public void createBoard() throws Exception {
    }

    @Test
    public void main() throws Exception {
    }
*/
}